<?php
    define('HOST', 'localhost');
    define('BD', 'marcasropa');
    define('USER', 'root');
    define('PASSWORD', '');
    define('CHARSET', 'utf8');
?>